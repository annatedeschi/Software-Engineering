package Planner;
import java.util.HashMap;
import java.util.Scanner;

public class WeddingGame {
    private static HashMap<String, String> userInfo = new HashMap<>(); // store usernames and passwords

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Welcome to Wedding Planner Pro the game! ");
        System.out.println("Are you a returning user? (yes/no)");
        String intro = scan.nextLine().trim().toLowerCase();

        if (intro.equals("yes")) {
            login(scan);
        } else if (intro.equals("no")) {
            register(scan);
        } else {
            System.out.println("ERROR: Invalid input. Please restart.");
            return;}

        // start game
        startWeddingPlanning();
        scan.close(); 
        }

    private static void login(Scanner scan) {
        System.out.println(" Login to Your Account");

        System.out.print("Enter your username: ");
        String username = scan.nextLine();

        if (userInfo.containsKey(username)) { // see if username exists
            System.out.print("Enter your password: ");
            String password = scan.nextLine();

            if (userInfo.get(username).equals(password)) {
                System.out.println(" Login successful! Let's start planning your wedding!\n");
            } else {
                System.out.println(" Incorrect password. Please restart and try again.");
                System.exit(0);
            }
        } else {
            System.out.println(" Username not found. Try again or create a new account.");
            System.exit(0);
        }}

    private static void register(Scanner scan) {
        System.out.println("Create a New Account!");
        while (true) {
            System.out.print("Create a username: ");
            String username = scan.nextLine();

            if (userInfo.containsKey(username)) {
                System.out.println(" Username already exists. Try a different one.");
                continue;}

            System.out.print("Create a password: ");
            String password = scan.nextLine();

            userInfo.put(username, password);
            System.out.println(" Account created successfully!");

            System.out.print("Would you like to add another account? (yes/no): ");
            String response = scan.nextLine().trim().toLowerCase();
            if (!response.equals("yes")) {
                break;}}

        System.out.println("\nYou're all set! Let's start planning your dream wedding! ");}

    private static void startWeddingPlanning() {
        System.out.println(" Welcome to the Wedding Planning Game! ");
        // add other classes.../change them lol
    }
}
