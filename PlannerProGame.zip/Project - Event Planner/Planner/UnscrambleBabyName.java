package Planner;
import java.util.Random;
import java.util.Scanner;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;

public class UnscrambleBabyName {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // list of names, (add more?)
        String[] babyFirstNames = {"Erika", "Robin", "Kathryn", "Julia", "Justin", "Ollie", "Dylan"};
        String[] babyMiddleNames = {"Elizabeth", "Katherine", "Juliette", "Rosemary", "James", "Harvey"};
        String[] babyLastNames = {"Douglas", "Jones", "Smith", "Harter", "Parker", "Wynn"};

        // select random name from list -
        String firstName = babyFirstNames[random.nextInt(babyFirstNames.length)];
        String middleName = babyMiddleNames[random.nextInt(babyMiddleNames.length)];
        String lastName = babyLastNames[random.nextInt(babyLastNames.length)];

        // scramble the names
        String scrambledFirst = scramble(firstName);
        String scrambledMiddle = scramble(middleName);
        String scrambledLast = scramble(lastName);

        System.out.println("It's time to guess the baby's name!");
        System.out.println("You will need to unscramble a first, middle, and last name.");
        System.out.println("You have 3 attempts for each name. Good luck!");

        // guess each name,,, F, M, L
        boolean guessedFirst = guessName(scanner, "First Name", scrambledFirst, firstName);
        boolean guessedMiddle = guessedFirst && guessName(scanner, "Middle Name", scrambledMiddle, middleName);
        boolean guessedLast = guessedMiddle && guessName(scanner, "Last Name", scrambledLast, lastName);

        // final pop up message - declaring
        if (guessedLast) {
            System.out.println("Congratulations! You unscrambled the full name: " 
                                + firstName + " " + middleName + " " + lastName);
        } else {
            System.out.println("Game over! The correct full name was: " 
                                + firstName + " " + middleName + " " + lastName);
        }

        scanner.close();
    }

    // Method scrambling a given name
    public static String scramble(String name) {
        List<Character> letters = Arrays.asList(new Character[name.length()]);
        for (int i = 0; i < name.length(); i++) {
            letters.set(i, name.charAt(i));
        }
        Collections.shuffle(letters);
        
        StringBuilder scrambled = new StringBuilder();
        for (char letter : letters) {
            scrambled.append(letter);}
        
        return scrambled.toString();}

    // method handling user guessing a name
    public static boolean guessName(Scanner scanner, String nameType, String scrambled, String correctName) {
        int attempts = 3;
        System.out.println(nameType + " to unscramble: " + scrambled);

        while (attempts > 0) {
            System.out.print("Your guess: ");
            String userGuess = scanner.nextLine().trim();

            if (userGuess.equalsIgnoreCase(correctName)) {
                System.out.println("Correct! The " + nameType.toLowerCase() + " was: " + correctName + "\n");
                return true;
            } else {
                attempts--;
                System.out.println("Wrong! Attempts left: " + attempts);
            }}

        return false; // user guessed incorrect
    }}
