package Planner;

import java.util.Scanner;
import java.util.Random;

public class DateGuesser {
    public static void guessDateMinigame() {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        // random due date - month+day
        int correctMonth = 1 + rand.nextInt(12);  
        int correctDay = 1 + rand.nextInt(31);   
        
        int totalGuesses = 10;  //attempts allotted
        int remainingGuesses = totalGuesses;
        int userGuess;

        System.out.println("A baby is due on a mystery date...");
        System.out.println("Try to guess the due date (MM/DD). You have " + totalGuesses + " attempts.");

        // month 
        System.out.println("\nFirst, guess the month (1-12):");
        while (remainingGuesses > 0) {
            System.out.print("Enter your guess for the month: ");
            userGuess = sc.nextInt();
            remainingGuesses--;

            if (userGuess == correctMonth) {
                System.out.println("Correct! Now guess the day.");
                break;
            } else if (userGuess < correctMonth) {
                System.out.println("The correct month is later.");
            } else {
                System.out.println("The correct month is earlier.");
            }

            if (remainingGuesses == 0) {
                System.out.println("You're out of guesses! The correct date was " + String.format("%02d", correctMonth) + "/" + String.format("%02d", correctDay));
                return;}}

        //  day
        System.out.println("\nNow, guess the day (1-31):");
        while (remainingGuesses > 0) {
            System.out.print("Enter your guess for the day: ");
            userGuess = sc.nextInt();
            remainingGuesses--;

            if (userGuess == correctDay) {
                System.out.println("Congratulations! You guessed the correct due date: " + String.format("%02d", correctMonth) + "/" + String.format("%02d", correctDay));
                return;
            } else if (userGuess < correctDay) {
                System.out.println("The correct day is later.");
            } else {
                System.out.println("The correct day is earlier.");}
            

            if (remainingGuesses == 0) {
                System.out.println("You're out of guesses! The correct date was " + String.format("%02d", correctMonth) + "/" + String.format("%02d", correctDay));
                return;}}}

    public static void main(String[] args) {
    	guessDateMinigame();}}






